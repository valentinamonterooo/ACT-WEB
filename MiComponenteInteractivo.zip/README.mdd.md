Componente Interactivo con JavaScript

## Descripción
Este proyecto consiste en un componente web interactivo que responde a una acción del usuario. Al hacer clic en un botón, se muestra un mensaje personalizado y cambia el color de fondo del sitio, generando una experiencia dinámica y atractiva.

##  Objetivos cumplidos
- Uso de eventos de JavaScript (`click`).
- Manipulación dinámica del DOM (`textContent`, `style.backgroundColor`).
- Implementación de estilos CSS organizados con Flexbox.
- Diseño adaptable y centrado.
- Asistencia de IA (ChatGPT) para la estructura del código y resolución de dudas.

##  ¿Cómo se usó ChatGPT?
ChatGPT ayudó a:
- Sugerir funciones limpias y legibles para el manejo de eventos.
- Optimizar el cambio dinámico de colores y estilos con transiciones.

## Herramientas utilizadas
- HTML5
- CSS3 (Flexbox)
- JavaScript 
- ChatGPT para soporte técnico
- DevTools de Chrome para pruebas responsive

##  Estructura de carpetas
```
MiComponenteInteractivo/
├── css/style.css
├── imágenes/fondo.jpg (opcional)
├── index.html
├── script.js
└── README.md
